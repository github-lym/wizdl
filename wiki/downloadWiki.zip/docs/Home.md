**Project Description**

wizdl is a .NET utility written in C# that allows you to quickly import and test web services within the comfort of a Windows Forms GUI.

It supports calling complex web services that take arrays and deeply nested objects as parameters.

![](Home_wizdl_adservice.jpg)