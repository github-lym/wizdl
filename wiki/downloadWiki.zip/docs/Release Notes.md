**Version 1**
* [release:v1.0](16181)
	* Initital release.
	* Support for _XML+SOAP_.
	* Core implementation via _Dynamic proxy pattern_. More information on this especially targeting webservices could be found in this article - [http://blogs.msdn.com/b/kaevans/archive/2006/04/27/dynamically-invoking-a-web-service.aspx](Dynamically Invoking a Web Service)
* [release:v1.1](26569)
	* Added file save and load support.
**In Development/Assesment**
* [release:v1.2](101087)
	* [workitem:Bugfix 21806](21806)
	* [workitem:Bugfix 25992](25992)
**Version 2**
* v1.2.99
	* Port to _WPF_.
	* Each webservice will be separated in own _application domain_.
	* [discussion:Suggestions](34823)